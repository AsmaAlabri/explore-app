import '../app_settings.dart';

/// In-app translation table. No code generation, no .arb files —
/// just add a new key/entry here whenever a new page needs text,
/// then call tr('your_key') wherever that text is shown.
class AppStrings {
  AppStrings._();

  static const Map<String, Map<String, String>> _values = {
    // Drawer / navigation
    'home': {'en': 'Home', 'ar': 'الرئيسية'},
    'about_oman': {'en': 'About Oman', 'ar': 'عن عُمان'},
    'explore': {'en': 'Explore', 'ar': 'استكشف'},
    'events': {'en': 'Events', 'ar': 'الفعاليات'},
    'notifications': {'en': 'Notifications', 'ar': 'الإشعارات'},
    'profile_settings': {
      'en': 'Profile & Settings',
      'ar': 'الملف الشخصي والإعدادات',
    },
    'help_support': {'en': 'Help & Support', 'ar': 'المساعدة والدعم'},
    'about_us': {'en': 'About us', 'ar': 'من نحن'},
    'logout': {'en': 'Logout', 'ar': 'تسجيل الخروج'},
    'need_help': {'en': 'Need help?', 'ar': 'تحتاج مساعدة؟'},

    // Home page
    'welcome_title': {
      'en': 'Welcome To Sultanate of Oman',
      'ar': 'مرحبًا بكم في سلطنة عُمان',
    },
    'home_intro': {
      'en':
          'The Sultanate of Oman features a vibrant and varied natural '
          'environment, combining plains, oceans, deserts, highlands, '
          'springs, valleys, and fertile vegetation. Moreover, cities '
          'today, modern infrastructure, heritage markets, ancient '
          'forts, and evenly allocated services and amenities enhance '
          'this scenery nationwide.\n\n'
          'Oman showcases a distinctive blend of historic cities, '
          'mountainous rural towns, contemporary lifestyle, and the '
          'enduring riches of genuine Arab culture. It is recognized '
          'for its hospitable and friendly residents, along with its '
          'top safety rankings globally. Omani hospitality is firmly '
          'based in tradition, where guests are greeted with authentic '
          'respect and kindness, fostering an atmosphere of genuine '
          'gratitude and concern. This nation offers thrilling choices '
          'for adventurers, including mountain climbing, hiking, '
          'diving, fishing, surfing, and exploring ancient caves like '
          'Al Hoota Cave and Majlis al Jinn Cave',
      'ar':
          'تتميز سلطنة عُمان ببيئة طبيعية نابضة بالحياة ومتنوعة، تجمع '
          'بين السهول والمحيطات والصحاري والمرتفعات والينابيع والوديان '
          'والنباتات الخصبة. علاوة على ذلك، تعزز المدن الحديثة، '
          'والبنية التحتية العصرية، والأسواق التراثية، والحصون '
          'القديمة، والخدمات والمرافق الموزعة بالتساوي هذا المشهد في '
          'جميع أنحاء البلاد.\n\n'
          'تُظهر عُمان مزيجًا مميزًا من المدن التاريخية، والبلدات '
          'الريفية الجبلية، ونمط الحياة المعاصر، والثراء الدائم '
          'للثقافة العربية الأصيلة. وهي معروفة بسكانها المضيافين '
          'والودودين، إلى جانب تصنيفاتها العالمية العالية في مجال '
          'السلامة. تتجذر الضيافة العُمانية بعمق في التقاليد، حيث '
          'يُستقبل الضيوف باحترام وحفاوة أصيلين مما يخلق أجواءً من '
          'الامتنان والاهتمام الصادقين. تقدم هذه الدولة خيارات مثيرة '
          'للمغامرين، بما في ذلك تسلق الجبال والمشي لمسافات طويلة '
          'والغوص وصيد الأسماك وركوب الأمواج واستكشاف الكهوف القديمة '
          'مثل كهف الهوتة وكهف مجلس الجن',
    },
    'coming_soon_suffix': {'en': 'page coming soon', 'ar': 'الصفحة قادمة قريبًا'},
    'help_support_coming_soon': {
      'en': 'Help & Support coming soon',
      'ar': 'المساعدة والدعم قريبًا',
    },

    // Profile & settings page
    'loading': {'en': 'Loading...', 'ar': 'جاري التحميل...'},
    'account': {'en': 'Account', 'ar': 'الحساب'},
    'change_password': {'en': 'Change Password', 'ar': 'تغيير كلمة المرور'},
    'edit_profile': {'en': 'Edit Profile', 'ar': 'تعديل الملف الشخصي'},
    'theme': {'en': 'Theme', 'ar': 'المظهر'},
    'language': {'en': 'Language', 'ar': 'اللغة'},

    // Welcome page
    'join_explore_oman': {
      'en': 'JOIN US AND\nEXPLORE OMAN',
      'ar': 'انضم إلينا و\nاستكشف عُمان',
    },
    'get_started': {'en': 'GET STARTED!', 'ar': 'ابدأ الآن!'},

    // Login page
    'welcome_back': {'en': 'Welcome Back', 'ar': 'مرحبًا بعودتك'},
    'email_hint': {'en': 'Email', 'ar': 'البريد الإلكتروني'},
    'password_hint': {'en': 'Password', 'ar': 'كلمة المرور'},
    'role_hint': {'en': 'Role', 'ar': 'الدور'},
    'role_selection_label': {'en': 'I am a', 'ar': 'أنا'},
    'login_button': {'en': 'Login', 'ar': 'تسجيل الدخول'},
    'register_link': {'en': 'Register', 'ar': 'إنشاء حساب'},
    'forgot_password_link': {
      'en': 'Forgot Password',
      'ar': 'نسيت كلمة المرور',
    },
    'err_enter_email': {
      'en': 'Please enter email',
      'ar': 'يرجى إدخال البريد الإلكتروني',
    },
    'err_invalid_email': {
      'en': 'Invalid email',
      'ar': 'بريد إلكتروني غير صالح',
    },
    'err_enter_password': {
      'en': 'Please enter password',
      'ar': 'يرجى إدخال كلمة المرور',
    },
    'err_min_8_chars': {
      'en': 'Minimum 8 characters',
      'ar': 'الحد الأدنى 8 أحرف',
    },

    // Register page
    'create_account': {'en': 'Create Account', 'ar': 'إنشاء حساب'},
    'full_name_hint': {'en': 'Full Name', 'ar': 'الاسم الكامل'},
    'confirm_password_hint': {
      'en': 'Confirm Password',
      'ar': 'تأكيد كلمة المرور',
    },
    'password_requirements_hint': {
      'en': 'Password must contain uppercase, lowercase,\n'
          'number and special character',
      'ar': 'يجب أن تحتوي كلمة المرور على حرف كبير وحرف صغير\n'
          'ورقم ورمز خاص',
    },
    'register_button': {'en': 'Register', 'ar': 'إنشاء حساب'},
    'already_have_account': {
      'en': 'Already have an account? ',
      'ar': 'لديك حساب بالفعل؟ ',
    },
    'err_enter_name': {
      'en': 'Please enter your name',
      'ar': 'يرجى إدخال اسمك',
    },
    'err_name_min_3': {
      'en': 'Name must be at least 3 characters',
      'ar': 'يجب أن يتكون الاسم من 3 أحرف على الأقل',
    },
    'err_enter_valid_email': {
      'en': 'Enter valid email',
      'ar': 'أدخل بريدًا إلكترونيًا صالحًا',
    },
    'err_password_strength': {
      'en': 'Password must contain:\n'
          '- 8 characters\n'
          '- Uppercase letter\n'
          '- Lowercase letter\n'
          '- Number\n'
          '- Special character',
      'ar': 'يجب أن تحتوي كلمة المرور على:\n'
          '- 8 أحرف\n'
          '- حرف كبير\n'
          '- حرف صغير\n'
          '- رقم\n'
          '- رمز خاص',
    },
    'err_confirm_password': {
      'en': 'Please confirm password',
      'ar': 'يرجى تأكيد كلمة المرور',
    },
    'err_passwords_mismatch': {
      'en': 'Passwords do not match',
      'ar': 'كلمتا المرور غير متطابقتين',
    },
    'register_success': {
      'en': 'Registration successful. Please log in.',
      'ar': 'تم التسجيل بنجاح. يرجى تسجيل الدخول.',
    },
    'register_success_profile_fail': {
      'en': 'Registration successful, but profile details were not saved.',
      'ar': 'تم التسجيل بنجاح، ولكن لم يتم حفظ تفاصيل الملف الشخصي.',
    },

    // Forgot / reset password
    'forgot_password_title': {
      'en': 'Forgot Password',
      'ar': 'نسيت كلمة المرور',
    },
    'send_reset_link': {
      'en': 'Send Reset Link',
      'ar': 'إرسال رابط إعادة التعيين',
    },
    'back_to_login': {'en': 'Back to Login', 'ar': 'العودة لتسجيل الدخول'},
    'reset_link_sent': {
      'en': 'Password reset link sent to your email',
      'ar': 'تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني',
    },
    'reset_password_title': {
      'en': 'Reset Password',
      'ar': 'إعادة تعيين كلمة المرور',
    },
    'reset_your_password_heading': {
      'en': 'Reset Your Password',
      'ar': 'أعد تعيين كلمة المرور',
    },
    'old_password_hint': {
      'en': 'Old Password',
      'ar': 'كلمة المرور القديمة',
    },
    'new_password_hint': {
      'en': 'New Password',
      'ar': 'كلمة المرور الجديدة',
    },
    'err_enter_old_password': {
      'en': 'Enter old password',
      'ar': 'أدخل كلمة المرور القديمة',
    },
    'err_enter_new_password': {
      'en': 'Enter new password',
      'ar': 'أدخل كلمة المرور الجديدة',
    },
    'err_new_password_same': {
      'en': 'New password must be different',
      'ar': 'يجب أن تكون كلمة المرور الجديدة مختلفة',
    },
    'err_weak_password': {'en': 'Weak password', 'ar': 'كلمة مرور ضعيفة'},
    'err_incorrect_old_password': {
      'en': 'The old password you entered is incorrect.',
      'ar': 'كلمة المرور القديمة التي أدخلتها غير صحيحة.',
    },
    'password_updated_success': {
      'en': 'Password Updated Successfully',
      'ar': 'تم تحديث كلمة المرور بنجاح',
    },
    'login_again_message': {
      'en': 'Please log in again to change your password',
      'ar': 'يرجى تسجيل الدخول مرة أخرى لتغيير كلمة المرور',
    },

    // About Oman page
    'about_oman_intro': {
      'en': 'The Sultanate of Oman features a vibrant and varied natural '
          'environment, combining plains, oceans, deserts, highlands, '
          'springs, valleys, and fertile vegetation. Moreover, cities '
          'today, modern infrastructure, heritage markets, ancient '
          'forts, and evenly allocated services and amenities enhance '
          'this scenery nationwide.\n\n'
          'Oman showcases a distinctive blend of historic cities, '
          'mountainous rural towns, contemporary lifestyle, and the '
          'enduring riches of Arab culture. It is recognized for its '
          'hospitable and friendly residents, along with its top '
          'safety rankings globally. Omani hospitality is firmly '
          'based in tradition, where guests are greeted with authentic '
          'respect and kindness, fostering an atmosphere of genuine '
          'gratitude and concern.\n\n'
          'This nation offers thrilling choices for adventurers, '
          'including mountain climbing, hiking, diving, fishing, '
          'surfing, and exploring ancient caves like Al Hoota Cave '
          'and Majlis al Jinn Cave.',
      'ar': 'تتميز سلطنة عُمان ببيئة طبيعية نابضة بالحياة ومتنوعة، تجمع '
          'بين السهول والمحيطات والصحاري والمرتفعات والينابيع والوديان '
          'والنباتات الخصبة. علاوة على ذلك، تعزز المدن الحديثة، '
          'والبنية التحتية العصرية، والأسواق التراثية، والحصون '
          'القديمة، والخدمات والمرافق الموزعة بالتساوي هذا المشهد في '
          'جميع أنحاء البلاد.\n\n'
          'تُظهر عُمان مزيجًا مميزًا من المدن التاريخية، والبلدات '
          'الريفية الجبلية، ونمط الحياة المعاصر، والثراء الدائم '
          'للثقافة العربية. وهي معروفة بسكانها المضيافين والودودين، '
          'إلى جانب تصنيفاتها العالمية العالية في مجال السلامة. '
          'تتجذر الضيافة العُمانية بعمق في التقاليد، حيث يُستقبل '
          'الضيوف باحترام وحفاوة أصيلين مما يخلق أجواءً من الامتنان '
          'والاهتمام الصادقين.\n\n'
          'تقدم هذه الدولة خيارات مثيرة للمغامرين، بما في ذلك تسلق '
          'الجبال والمشي لمسافات طويلة والغوص وصيد الأسماك وركوب '
          'الأمواج واستكشاف الكهوف القديمة مثل كهف الهوتة وكهف مجلس '
          'الجن.',
    },

    // Notifications page
    'no_notifications_yet': {
      'en': "You're all caught up. No notifications yet.",
      'ar': 'أنت على اطلاع بكل شيء. لا توجد إشعارات بعد.',
    },

    // Feedback page
    'feedback': {'en': 'Feedback', 'ar': 'التقييم'},
    'feedback_prompt': {
      'en': 'Tell us about your experience',
      'ar': 'أخبرنا عن تجربتك',
    },
    'feedback_hint': {
      'en': 'Write your feedback here ...',
      'ar': 'اكتب ملاحظاتك هنا ...',
    },
        'rating_value_label': {'en': '{n} out of 5', 'ar': '{n} من 5'},
    'tag_easy_to_use': {'en': 'Easy to use', 'ar': 'سهل الاستخدام'},
    'tag_helpful_info': {
      'en': 'Helpful information',
      'ar': 'معلومات مفيدة',
    },
    'tag_needs_improvement': {
      'en': 'Needs Improvement',
      'ar': 'يحتاج إلى تحسين',
    },
    'submit_feedback': {'en': 'Submit Feedback', 'ar': 'إرسال التقييم'},
    'select_rating_first': {
      'en': 'Please select a star rating first.',
      'ar': 'يرجى اختيار تقييم بالنجوم أولاً.',
    },
    'feedback_thanks': {
      'en': 'Thanks for your feedback!',
      'ar': 'شكرًا لملاحظاتك!',
    },
    'feedback_submit_error_prefix': {
      'en': 'Could not submit feedback: ',
      'ar': 'تعذر إرسال الملاحظات: ',
    },

    // Place details page
    'place_details_title': {
      'en': 'Place Details',
      'ar': 'تفاصيل المكان',
    },
    'view_on_map': {'en': 'View on Map', 'ar': 'عرض على الخريطة'},
    'give_feedback': {'en': 'Give Feedback', 'ar': 'إرسال ملاحظات'},
    'share': {'en': 'Share', 'ar': 'مشاركة'},
    'opening_map_prefix': {'en': 'Opening ', 'ar': 'جارٍ فتح '},
    'opening_map_suffix': {
      'en': ' on the map...',
      'ar': ' على الخريطة...',
    },
    'could_not_open_map': {
      'en': 'Could not open the map.',
      'ar': 'تعذر فتح الخريطة.',
    },

    // Explore / Events search pages
    'destinations_title': {'en': 'Destinations', 'ar': 'الوجهات'},
    'search_destination_hint': {
      'en': 'Search destination...',
      'ar': 'ابحث عن وجهة...',
    },
    'no_destinations_match': {
      'en': 'No destinations match your search.',
      'ar': 'لا توجد وجهات مطابقة لبحثك.',
    },
    'search_events_hint': {
      'en': 'Search events...',
      'ar': 'ابحث عن الفعاليات...',
    },
    'no_events_match': {
      'en': 'No events match your search.',
      'ar': 'لا توجد فعاليات مطابقة لبحثك.',
    },

    // About Us page
    'about_us_title': {
      'en': 'About Explore Oman',
      'ar': 'عن تطبيق استكشف عُمان',
    },
    'about_us_intro': {
      'en': 'Explore Oman is a mobile app built to help residents and '
          "visitors discover the Sultanate's culture, destinations, "
          'and events in one place. It was created as a graduation '
          "project, with the goal of making it easier to explore Oman's "
          'heritage sites, plan visits to festivals and attractions, '
          'and share feedback that helps other travelers.\n\n'
          'This app is actively being developed, and new features are '
          'added regularly.',
      'ar': 'استكشف عُمان تطبيق للهواتف المحمولة صُمم لمساعدة المقيمين '
          'والزوار على اكتشاف ثقافة السلطنة ووجهاتها وفعالياتها في '
          'مكان واحد. تم إنشاؤه كمشروع تخرج، بهدف تسهيل استكشاف مواقع '
          'التراث في عُمان، والتخطيط لزيارة المهرجانات والمعالم '
          'السياحية، ومشاركة الملاحظات التي تساعد المسافرين الآخرين.\n\n'
          'يخضع هذا التطبيق للتطوير المستمر، وتتم إضافة ميزات جديدة '
          'بانتظام.',
    },

    // Help & Support page
    'help_support_intro': {
      'en': 'Find quick answers below, or reach out to us directly if '
          'you need more help.',
      'ar': 'اعثر على إجابات سريعة أدناه، أو تواصل معنا مباشرة إذا كنت '
          'بحاجة إلى مزيد من المساعدة.',
    },
    'faq_q1': {
      'en': 'How do I create an account?',
      'ar': 'كيف يمكنني إنشاء حساب؟',
    },
    'faq_a1': {
      'en': 'On the Welcome screen, tap Get Started, then Register to '
          'create a new account with your name, email, and password.',
      'ar': 'في شاشة الترحيب، اضغط على ابدأ الآن، ثم إنشاء حساب لإنشاء '
          'حساب جديد باستخدام اسمك وبريدك الإلكتروني وكلمة المرور.',
    },
    'faq_q2': {
      'en': 'How do I switch the app language?',
      'ar': 'كيف يمكنني تغيير لغة التطبيق؟',
    },
    'faq_a2': {
      'en': 'Open the menu and go to Profile & Settings, then tap ENG '
          'or عربي under Language.',
      'ar': 'افتح القائمة وانتقل إلى الملف الشخصي والإعدادات، ثم اضغط '
          'على ENG أو عربي ضمن اللغة.',
    },
    'faq_q3': {
      'en': 'How do I turn on dark mode?',
      'ar': 'كيف يمكنني تفعيل الوضع الداكن؟',
    },
    'faq_a3': {
      'en': 'Open Profile & Settings and tap the moon icon under Theme.',
      'ar': 'افتح الملف الشخصي والإعدادات واضغط على أيقونة القمر ضمن '
          'المظهر.',
    },
    'faq_q4': {
      'en': 'I forgot my password. What should I do?',
      'ar': 'نسيت كلمة المرور، ماذا أفعل؟',
    },
    'faq_a4': {
      'en': 'On the Login screen, tap Forgot Password and enter your '
          'email to receive a reset link.',
      'ar': 'في شاشة تسجيل الدخول، اضغط على نسيت كلمة المرور وأدخل '
          'بريدك الإلكتروني لتلقي رابط إعادة التعيين.',
    },
    'faq_q5': {
      'en': 'How do I leave feedback about a place or event?',
      'ar': 'كيف يمكنني ترك ملاحظات حول مكان أو فعالية؟',
    },
    'faq_a5': {
      'en': 'Open a destination or event from Explore or Events, then '
          'tap Give Feedback to rate it and leave a comment.',
      'ar': 'افتح وجهة أو فعالية من استكشف أو الفعاليات، ثم اضغط على '
          'إرسال ملاحظات لتقييمها وترك تعليق.',
    },
    'contact_us': {'en': 'Contact Us', 'ar': 'تواصل معنا'},
    'contact_email_value': {
      'en': 'support@exploreoman.app',
      'ar': 'support@exploreoman.app',
    },
    'copied_to_clipboard': {
      'en': 'Email copied to clipboard',
      'ar': 'تم نسخ البريد الإلكتروني',
    },

    // User roles
    'role_admin': {'en': 'Admin', 'ar': 'مسؤول'},
    'role_business_owner': {
      'en': 'Local Business Owner',
      'ar': 'صاحب عمل محلي',
    },
    'role_tourist': {'en': 'Tourist', 'ar': 'سائح'},

    // Destination content (Explore page)
    'dest1_name': {
      'en': 'Oman Across Ages Museum',
      'ar': 'متحف عُمان عبر العصور',
    },
    'dest1_location': {'en': 'Manah', 'ar': 'منح'},
    'dest1_description': {
      'en': "Discover Oman's rich legacy through immersive exhibits "
          'and cultural artifacts dating back thousands of years.',
      'ar': 'اكتشف تراث عُمان الغني من خلال معارض تفاعلية وقطع أثرية '
          'ثقافية يعود تاريخها إلى آلاف السنين.',
    },
    'dest1_details': {
      'en': "Wilayat Manah's Oman Across Ages Museum provides guests "
          "with an enthralling voyage through the country's rich "
          "natural heritage, history, and culture. The museum's "
          'interactive displays and state-of-the-art technologies '
          "are intended to captivate visitors of all ages, bringing "
          "Oman's history to life in a distinctive and unforgettable "
          'way.',
      'ar': 'يقدم متحف عُمان عبر العصور في ولاية منح للزوار رحلة '
          'آسرة عبر تراث البلاد الطبيعي وتاريخها وثقافتها الغنية. '
          'صُممت العروض التفاعلية والتقنيات الحديثة في المتحف '
          'لجذب الزوار من جميع الأعمار، مما يعيد تاريخ عُمان إلى '
          'الحياة بطريقة مميزة لا تُنسى.',
    },
    'dest2_name': {'en': 'Bar Al Hikman', 'ar': 'بر الحكمان'},
    'dest2_location': {'en': 'Al Wusta', 'ar': 'الوسطى'},
    'dest2_description': {
      'en': 'Bar Al Hikman is an island located in the center of '
          "Oman's coast and is considered to be one of the most "
          'important bird migration...',
      'ar': 'بر الحكمان جزيرة تقع في وسط ساحل عُمان، وتُعد من أهم '
          'مواقع هجرة الطيور...',
    },
    'dest2_details': {
      'en': 'Bar Al Hikman is a vast coastal wetland and peninsula '
          'on the Arabian Sea, renowned as one of the most important '
          'migratory bird stopover sites in the Middle East, hosting '
          'hundreds of thousands of shorebirds each year.',
      'ar': 'بر الحكمان هو أرض رطبة ساحلية شاسعة وشبه جزيرة على بحر '
          'العرب، تشتهر بكونها واحدة من أهم محطات توقف الطيور '
          'المهاجرة في الشرق الأوسط، حيث تستقبل مئات الآلاف من '
          'طيور الشواطئ كل عام.',
    },
    'dest3_name': {'en': 'Nizwa Fort', 'ar': 'حصن نزوى'},
    'dest3_location': {'en': 'Ad Dakhiliyah', 'ar': 'الداخلية'},
    'dest3_description': {
      'en': 'Nizwa Fort, the largest of its kind in the Arabian '
          'Peninsula, is a massive circular stronghold built from '
          'mud by Imam Sultan bin Saif Al-...',
      'ar': 'حصن نزوى، أكبر حصن من نوعه في شبه الجزيرة العربية، هو '
          'معقل دائري ضخم بناه الإمام سلطان بن سيف...',
    },
    'dest3_details': {
      'en': "Nizwa Fort was built in the 17th century and is one of "
          "Oman's most visited national monuments, famous for its "
          'massive circular tower, defensive design, and sweeping '
          'views over Nizwa and the surrounding date palm oasis.',
      'ar': 'بُني حصن نزوى في القرن السابع عشر، وهو أحد أكثر '
          'المعالم الوطنية زيارةً في عُمان، ويشتهر ببرجه الدائري '
          'الضخم وتصميمه الدفاعي وإطلالاته الخلابة على نزوى وواحة '
          'النخيل المحيطة بها.',
    },
    'dest4_name': {
      'en': 'Sultan Qaboos Grand Mosque',
      'ar': 'جامع السلطان قابوس الأكبر',
    },
    'dest4_location': {'en': 'Muscat', 'ar': 'مسقط'},
    'dest4_description': {
      'en': 'Sultan Qaboos Grand Mosque is one of the most '
          'recognizable architectural and religious landmarks in '
          'Oman.',
      'ar': 'جامع السلطان قابوس الأكبر هو أحد أبرز المعالم '
          'المعمارية والدينية في عُمان.',
    },
    'dest4_details': {
      'en': 'Completed in 2001, the Grand Mosque can hold up to '
          '20,000 worshippers and is known for its enormous '
          'hand-woven Persian carpet and one of the largest '
          'single-piece chandeliers in the world.',
      'ar': 'اكتمل بناء الجامع الأكبر عام 2001، ويتسع لأكثر من '
          '20,000 مصلٍ، ويشتهر بسجادته الفارسية الضخمة المصنوعة '
          'يدويًا وواحدة من أكبر الثريات ذات القطعة الواحدة في '
          'العالم.',
    },

    // Event content (Events page)
    'event1_name': {'en': 'Muscat Festival', 'ar': 'مهرجان مسقط'},
    'event1_location': {'en': 'Muscat', 'ar': 'مسقط'},
    'event1_description': {
      'en': 'Oman welcomes you all to start the new year by '
          'exploring the Muscat night festivals.',
      'ar': 'ترحب عُمان بالجميع لبدء العام الجديد من خلال استكشاف '
          'مهرجانات مسقط الليلية.',
    },
    'event1_info1': {
      'en': 'Date: The Muscat festival 2026 dates are expected to '
          'run from January to February 2026.',
      'ar': 'التاريخ: من المتوقع أن يقام مهرجان مسقط 2026 من '
          'يناير إلى فبراير 2026.',
    },
    'event1_info2': {
      'en': 'Timing: 4:00 PM - 11:00 PM',
      'ar': 'التوقيت: 4:00 مساءً - 11:00 مساءً',
    },
    'event1_info3': {
      'en': 'Things To Do: Explore the open-air stage shows during '
          'the Muscat night festival, look at the local artefacts '
          'and taste the famous cuisine of Oman.',
      'ar': 'الأنشطة: استكشف العروض المسرحية في الهواء الطلق خلال '
          'مهرجان مسقط الليلي، وشاهد الحرف المحلية وتذوق المأكولات '
          'العُمانية الشهيرة.',
    },
    'event2_name': {
      'en': 'Salalah Tourism Festival',
      'ar': 'مهرجان صلالة السياحي',
    },
    'event2_location': {'en': 'Salalah', 'ar': 'صلالة'},
    'event2_description': {
      'en': 'The Festival is a famous attraction to tourists. This '
          'festival in Salalah has expanded to an international '
          'festival because of the high efforts.',
      'ar': 'يُعد المهرجان جذبًا مشهورًا للسياح، وقد توسع هذا '
          'المهرجان في صلالة ليصبح مهرجانًا عالميًا بفضل الجهود '
          'الكبيرة.',
    },
    'event2_info1': {
      'en': 'Date: Held annually during the Khareef (monsoon) '
          'season, typically July to September.',
      'ar': 'التاريخ: يُقام سنويًا خلال موسم الخريف، عادةً من '
          'يوليو إلى سبتمبر.',
    },
    'event2_info2': {
      'en': 'Timing: Evening hours, from around 4:00 PM until late.',
      'ar': 'التوقيت: ساعات المساء، من حوالي الرابعة عصرًا حتى '
          'وقت متأخر.',
    },
    'event2_info3': {
      'en': 'Things To Do: Enjoy cultural pavilions, live music, '
          'local produce markets, and the cool Salalah monsoon '
          'weather.',
      'ar': 'الأنشطة: استمتع بالأجنحة الثقافية والموسيقى الحية '
          'وأسواق المنتجات المحلية وأجواء الخريف الباردة في صلالة.',
    },
    'event3_name': {
      'en': 'Muscat International Book Fair',
      'ar': 'معرض مسقط الدولي للكتاب',
    },
    'event3_location': {'en': 'Muscat', 'ar': 'مسقط'},
    'event3_description': {
      'en': 'Get to see books related to Omani heritage and '
          'history, which further contribute to enhancing cultural '
          'understanding.',
      'ar': 'تعرف على الكتب المتعلقة بالتراث والتاريخ العُماني، '
          'مما يسهم في تعزيز الفهم الثقافي.',
    },
    'event3_info1': {
      'en': 'Date: Usually held in February each year.',
      'ar': 'التاريخ: يُقام عادةً في فبراير من كل عام.',
    },
    'event3_info2': {
      'en': 'Timing: Daily, morning through evening.',
      'ar': 'التوقيت: يوميًا، من الصباح حتى المساء.',
    },
    'event3_info3': {
      'en': 'Things To Do: Browse regional and international '
          'publishers, attend author talks, and pick up books on '
          'Omani history and culture.',
      'ar': 'الأنشطة: تصفح إصدارات دور النشر المحلية والعالمية، '
          'واحضر لقاءات مع المؤلفين، واقتنِ كتبًا عن تاريخ عُمان '
          'وثقافتها.',
    },
    'event4_name': {'en': 'Oman Marathon 2026', 'ar': 'ماراثون عُمان 2026'},
    'event4_location': {'en': 'Muscat', 'ar': 'مسقط'},
    'event4_description': {
      'en': 'Escape to Oman Marathon blended with adventures, '
          'vibrant coastal views making it a perfect event for '
          'runners and creates a memorable journey.',
      'ar': 'اهرب إلى ماراثون عُمان الممزوج بالمغامرة والإطلالات '
          'الساحلية النابضة بالحياة، مما يجعله فعالية مثالية '
          'للعدائين ويخلق رحلة لا تُنسى.',
    },
    'event4_info1': {
      'en': 'Date: Typically held in January.',
      'ar': 'التاريخ: يُقام عادةً في يناير.',
    },
    'event4_info2': {
      'en': 'Timing: Early morning start, around 6:00 AM.',
      'ar': 'التوقيت: بداية مبكرة في الصباح، حوالي الساعة 6:00 '
          'صباحًا.',
    },
    'event4_info3': {
      'en': 'Things To Do: Run the coastal course, cheer at the '
          'finish line festival, or join the family fun-run.',
      'ar': 'الأنشطة: اركض على المسار الساحلي، احتفل عند خط '
          'النهاية، أو شارك في سباق الجري العائلي.',
    },
  };

  static String of(String key) {
    final languageCode = AppSettings.instance.locale.languageCode;
    final entry = _values[key];
    if (entry == null) return key;
    return entry[languageCode] ?? entry['en'] ?? key;
  }
}

/// Shorthand so call sites can just write tr('home') instead of
/// AppStrings.of('home').
String tr(String key) => AppStrings.of(key);